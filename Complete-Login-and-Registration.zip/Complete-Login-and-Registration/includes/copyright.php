

<h4>PHP Login/Registration System -  Ravi Bandakkanavar</h4>
<h5>Copyright &copy;<?php echo date('Y');?> 
  
</h5>


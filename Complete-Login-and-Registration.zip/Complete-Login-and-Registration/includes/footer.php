
                <div id="footer" class="cf">
	 © Krazytech
        </div>
        
       
    </body>
</html>

<?php 
    define('TITLE',"Home | Complete Registertion From");
    include 'includes/header.php';
?>
<div id="philosophy">
    <hr>
    <br><br>
    <h1>Advanced Login and Registration Application</h1>
    <br><br>
    <p> Let us walk you through Complete Login and Registration Application using PHP and MySQL</p>
    
    <br><br><br>
    
</div>

<?php 
    include 'includes/footer.php';
?>
